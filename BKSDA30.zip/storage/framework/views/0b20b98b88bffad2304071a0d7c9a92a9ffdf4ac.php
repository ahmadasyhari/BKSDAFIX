<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Tambah Menu</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    <script defer src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!-- Gunakan versi CDN TinyMCE yang tidak membutuhkan API Key -->
    <script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/nav.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/nav.js'); ?>
</head>

<body>
    <main class="wrapper d-flex align-items-stretch">
        <nav id="sidebar" class="navbar-dark nav-bg-dark" style="min-height:100vh">
            <div class="custom-menu">
                <button type="button" id="sidebarCollapse" class="btn btn-dark">
                    <i class="fa fa-bars"></i>
                    <span class="sr-only">Toggle Menu</span>
                </button>
            </div>
            <div class="container-fluid d-grid justify-content-stretch text-center px-0 py-4">
                <ul class="nav flex-column">
                    <li class="nav-item py-3">
                        <img src="/images/profile.png" alt="Logo" width="75" height="auto">
                        <h4 class="my-3">Admin</h4>
                    </li>
                </ul>
                <hr style="margin: 0rem;">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link py-3" href="<?php echo e(route('menu.create')); ?>">
                            Beranda
                        </a>
                    </li>
                    <hr style="margin: 0rem;">
                    <li class="nav-item">
                        <a class="nav-link py-3 active" aria-current="page" href="<?php echo e(route('menu.create')); ?>">
                            Mengelola Menu
                        </a>
                    </li>
                    <hr style="margin: 0rem;">
                    <li class="nav-item">
                        <a class="nav-link py-3" href="#">Mengelola Pengumuman</a>
                    </li>
                    <hr style="margin: 0rem;">
                    <li class="nav-item">
                        <a class="nav-link py-3" href="#">Mengelola Artikel / Berita</a>
                    </li>
                    <hr style="margin: 0rem;">
                    <li class="nav-item">
                        <a class="nav-link py-3" href="#">Mengelola Video</a>
                    </li>
                    <hr style="margin: 0rem;">
                    <li class="nav-item">
                        <a class="nav-link py-3" href="#">Mengelola Foto</a>
                </ul>
            </div>
            <!-- Sidebar content -->
        </nav>

        <!-- Section Block -->
        <section class="container-fluid p-0">
            <nav class="navbar navbar-expand-lg nav-bg-dark px-2">
                <div class="container-fluid">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link d-flex align-items-center p-0" href="#"><span
                                    class="material-symbols-outlined text-white fs-2">settings
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            


            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <section id="content" class="p-4 p-md-5">
                <p class="mb-4">Beranda / Mengelola Pengumuman</p>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Judul</th>
                            <th>Kategori</th>
                            <th>Dibuat Pada</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($berita->id); ?></td>
                                <td><?php echo e($berita->judul); ?></td>
                                <td><?php echo e($berita->kategori->nama); ?></td>
                                <td><?php echo e($berita->created_at); ?></td>
                                <td>
                                    <a href="#" class="btn btn-warning btn-sm">Edit</a>
                                    <form action="<?php echo e(route('berita.destroy', $berita->id)); ?>" method="POST"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <a href="<?php echo e(route('berita.create')); ?>" class="btn btn-primary">Tambah Berita</a>
            </section>
        </section>
        <script>
            // Fungsi untuk menampilkan input yang sesuai
            function toggleContentInput() {
                var type = document.getElementById('type').value;
                if (type === 'url') {
                    document.getElementById('url-input').style.display = 'block';
                    document.getElementById('rich-text-input').style.display = 'none';
                    document.querySelector('textarea[name=content]').style.display = 'none'; // Hide textarea
                } else {
                    document.getElementById('url-input').style.display = 'none';
                    document.getElementById('rich-text-input').style.display = 'block';
                    document.querySelector('textarea[name=content]').style.display = 'block'; // Show textarea

                    // Inisialisasi TinyMCE
                    if (!tinymce.activeEditor) {
                        tinymce.init({
                            selector: '#editor',
                            width: 600,
                            height: 300,
                            plugins: [
                                'advlist', 'autolink', 'link', 'image', 'lists', 'charmap', 'preview', 'anchor',
                                'pagebreak',
                                'searchreplace', 'wordcount', 'visualblocks', 'code', 'fullscreen',
                                'insertdatetime', 'media',
                                'table', 'emoticons', 'help'
                            ],
                            toolbar: 'undo redo | styles | bold italic | alignleft aligncenter alignright alignjustify | ' +
                                'bullist numlist outdent indent | link image | print preview media fullscreen | ' +
                                'forecolor backcolor emoticons | help',
                            menu: {
                                favs: {
                                    title: 'My Favorites',
                                    items: 'code visualaid | searchreplace | emoticons'
                                }
                            },
                            menubar: 'favs file edit view insert format tools table help',
                            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }',
                            setup: function(editor) {
                                editor.on('init', function() {
                                    // Transfer the content from the textarea to the editor
                                    editor.setContent(document.querySelector('textarea[name=content]')
                                        .value || '');
                                });
                            }
                        });
                    }
                }
            }

            // Menyimpan konten TinyMCE ke textarea sebelum form disubmit
            document.querySelector('form').onsubmit = function() {
                if (document.getElementById('type').value === 'rich_text') {
                    document.querySelector('textarea[name=content]').value = tinymce.activeEditor.getContent();
                }
            };

            // Call toggleContentInput() on page load to initialize the state
            document.addEventListener('DOMContentLoaded', function() {
                toggleContentInput();
            });
        </script>
    </main>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/abrar/DiskD/myprojects/laravel/BKSDA/resources/views/admin/index_berita.blade.php ENDPATH**/ ?>