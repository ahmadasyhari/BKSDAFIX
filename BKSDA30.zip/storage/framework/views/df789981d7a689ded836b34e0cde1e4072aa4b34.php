

<?php $__env->startSection('nav'); ?>
    <nav id="sidebar" class="navbar-dark nav-bg-dark" style="min-height:100vh">
        <div class="custom-menu">
            <button type="button" id="sidebarCollapse" class="btn btn-dark">
                <i class="fa fa-bars"></i>
                <span class="sr-only">Toggle Menu</span>
            </button>
        </div>
        <div class="container-fluid d-grid justify-content-stretch text-center px-0 py-4">
            <ul class="nav flex-column">
                <li class="nav-item py-3">
                    <img src="/images/profile.png" alt="Logo" width="75" height="auto">
                    <h4 class="my-3">Admin</h4>
                </li>
            </ul>
            <hr style="margin: 0rem;">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link py-3" href="<?php echo e(route('home')); ?>">
                        Beranda
                    </a>
                </li>
                <hr style="margin: 0rem;">
                <li class="nav-item">
                    <a class="nav-link py-3 active" href="#" aria-current="page">
                        Mengelola Menu
                    </a>
                </li>
                <hr style="margin: 0rem;">
                <li class="nav-item">
                    <a class="nav-link py-3" href="<?php echo e(route('pengumuman.index')); ?>">Mengelola Pengumuman</a>
                </li>
                <hr style="margin: 0rem;">
                <li class="nav-item">
                    <a class="nav-link py-3" href="<?php echo e(route('artikel.index')); ?>">Mengelola Artikel</a>
                </li>
                <hr style="margin: 0rem;">
                <li class="nav-item">
                    <a class="nav-link py-3" href="#">Mengelola Video</a>
                </li>
                <hr style="margin: 0rem;">
                <li class="nav-item">
                    <a class="nav-link py-3" href="#">Mengelola Foto</a>
            </ul>
        </div>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <div id="content-header" class="container-fluid d-flex align-items-center px-4 py-3 bg-white mb-4">
        <p class="align-middle p-0 m-0 fs-5">Beranda / Mengelola Menu</p>
    </div>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success mx-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning">
            <?php echo e(session('warning')); ?>

            <form action="<?php echo e(route('menu.forceDelete', session('menu_id'))); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Ya, Hapus</button>
            </form>
            <a href="<?php echo e(route('menu.create')); ?>" class="btn btn-secondary">Batal</a>
        </div>
    <?php endif; ?>

    <section id="content" class="px-md-4">
        <div id="content" class="bg-white px-5 py-4">
            <h4 class="py-3">Form Tambah Menu</h4>
            <form action="<?php echo e(route('menu.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="title" class="form-label">Judul Menu</label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>

                <div class="mb-3">
                    <label for="type" class="form-label">Tipe Konten</label>
                    <select class="form-control" id="type" name="type" onchange="toggleContentInput()">
                        <option value="url">URL</option>
                        <option value="rich_text">Rich Text</option>
                    </select>
                </div>

                <div id="url-input" class="mb-3">
                    <label for="url" class="form-label">URL Menu</label>
                    <input type="text" class="form-control" id="url" name="url">
                </div>

                <div id="rich-text-input" class="mb-3" style="display:none;">
                    <label for="content" class="form-label">Konten Rich Text</label>
                    <div id="editor"></div>
                    <textarea class="form-control" id="content" name="content" style="display:none;"></textarea>
                </div>

                <div class="mb-3">
                    <label for="parent_id" class="form-label">Menu Induk</label>
                    <select class="form-control" id="parent_id" name="parent_id">
                        <option value="">Tidak Ada (Menu Utama)</option>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($menu->id); ?>"><?php echo e($menu->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-success">+ Tambah Menu</button>
            </form>

            <!-- Menampilkan daftar menu yang sudah dibuat dalam bentuk tabel responsif -->
            <div class="mt-4">
                <h4>Daftar Menu</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Judul Menu</th>
                                <th>URL</th>
                                <th>Konten</th>
                                <th>Induk/Sub-menu</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $allMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($menu->id); ?></td>
                                    <td><?php echo e($menu->title); ?></td>
                                    <td>
                                        <?php if($menu->url): ?>
                                            <a href="<?php echo e($menu->url); ?>" target="_blank"><?php echo e($menu->url); ?></a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($menu->content): ?>
                                            <?php echo Str::limit($menu->content, 50); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($menu->parent_id): ?>
                                            <span class="badge bg-secondary">Sub-menu dari ID:
                                                <?php echo e($menu->parent_id); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-primary">Menu Utama</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Tombol Hapus -->
                                        <form action="<?php echo e(route('menu.destroy', $menu->id)); ?>" method="POST"
                                            onsubmit="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
    </section>
    </section>
    <script>
        // Fungsi untuk menampilkan input yang sesuai
        function toggleContentInput() {
            var type = document.getElementById('type').value;
            if (type === 'url') {
                document.getElementById('url-input').style.display = 'block';
                document.getElementById('rich-text-input').style.display = 'none';
                document.querySelector('textarea[name=content]').style.display = 'none'; // Hide textarea
            } else {
                document.getElementById('url-input').style.display = 'none';
                document.getElementById('rich-text-input').style.display = 'block';
                document.querySelector('textarea[name=content]').style.display = 'block'; // Show textarea

                // Inisialisasi TinyMCE
                if (!tinymce.activeEditor) {
                    tinymce.init({
                        selector: '#editor',
                        width: 600,
                        height: 300,
                        plugins: [
                            'advlist', 'autolink', 'link', 'image', 'lists', 'charmap', 'preview', 'anchor',
                            'pagebreak',
                            'searchreplace', 'wordcount', 'visualblocks', 'code', 'fullscreen',
                            'insertdatetime', 'media',
                            'table', 'emoticons', 'help'
                        ],
                        toolbar: 'undo redo | styles | bold italic | alignleft aligncenter alignright alignjustify | ' +
                            'bullist numlist outdent indent | link image | print preview media fullscreen | ' +
                            'forecolor backcolor emoticons | help',
                        menu: {
                            favs: {
                                title: 'My Favorites',
                                items: 'code visualaid | searchreplace | emoticons'
                            }
                        },
                        menubar: 'favs file edit view insert format tools table help',
                        content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }',
                        setup: function(editor) {
                            editor.on('init', function() {
                                // Transfer the content from the textarea to the editor
                                editor.setContent(document.querySelector('textarea[name=content]')
                                    .value || '');
                            });
                        }
                    });
                }
            }
        }

        // Menyimpan konten TinyMCE ke textarea sebelum form disubmit
        document.querySelector('form').onsubmit = function() {
            if (document.getElementById('type').value === 'rich_text') {
                document.querySelector('textarea[name=content]').value = tinymce.activeEditor.getContent();
            }
        };

        // Call toggleContentInput() on page load to initialize the state
        document.addEventListener('DOMContentLoaded', function() {
            toggleContentInput();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/abrar/DiskD/myprojects/laravel/BKSDA/resources/views/admin/create_menu.blade.php ENDPATH**/ ?>